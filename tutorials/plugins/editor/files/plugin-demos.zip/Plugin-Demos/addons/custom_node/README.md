# Custom Node Plugin

This plugin demo shows one way to create a custom node type in Rebel Engine.

A custom node type:

* Derives from an existing node type.

* Shows up in the type list when adding a new node.

* Has a script attached to add new behavior.

* May have a custom icon.

The way it works in this plugin is using the `add_custom_type` and `remove_custom_type` in the plugin script file. Using this method you can specify any name, base type, script, and icon for your custom node.

There is also another way to add custom node types, which is using the `class_name` keyword in a script. However, the `class_name` system is newer, may change in the future, and it is not available for C# or VisualScript.
