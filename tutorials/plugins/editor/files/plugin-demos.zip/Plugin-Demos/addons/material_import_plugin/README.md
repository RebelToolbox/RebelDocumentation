# Material Import Plugin

This plugin shows how a custom import system can be added to the editor. In this case, it imports a material.

In Rebel Editor, try opening `test.mtxt`. Rebel Editor will recognize it and import it as a material because of this plugin.
